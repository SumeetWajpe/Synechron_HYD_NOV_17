var EventEmitter = require('events').EventEmitter;

function getIteration(maxIteration){
    var e = new EventEmitter();
    // Biz Logic
    process.nextTick(function(){
            e.emit('start');
            var cnt = 0;
           var t = setInterval(function(){
                e.emit('item',++cnt); // emit the data !
                if(cnt == 8){
                    e.emit('error');
                    clearInterval(t);
                }
                if(cnt == maxIteration){
                    e.emit('finish',cnt);
                    clearInterval(t);
                }
            },500);
    })
    return e;
}
var res = getIteration(10); // evtEmtr obj
res.on('start',function(){
    console.log('Started..');
});
res.on('error',function(){
    console.log('Error Occurred..');
});
res.on('item',function(theCount){
        console.log('Received : '  + theCount);
});
res.on('finish',function(theCount){
    console.log('The iteration ended with count : '  + theCount);
});

console.log('Program Ended !')