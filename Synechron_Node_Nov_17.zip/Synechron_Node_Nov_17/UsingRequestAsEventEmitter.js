var request = require('request');
var fs = require('fs');
var s = request('http://www.google.com');// returns is object of EventEmitter !
var response = '';

s.on('data',function(chunkOfData){
    console.log('\n\n>>>>>>>>> DATA>>>>>>>>>>\n\n');
    response += chunkOfData;
});
s.on('end',function(){
        console.log('>>>> DONE>>>>>');
        fs.writeFile('MyGoogleResponse.html',response);
});

// Using Callbacks

// var request = require('request');
// request('http://www.google.com', function (error, response, body) {
//   console.log('error:', error); // Print the error if one occurred
//   console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
//   console.log('body:', body); // Print the HTML for the Google homepage.
// });