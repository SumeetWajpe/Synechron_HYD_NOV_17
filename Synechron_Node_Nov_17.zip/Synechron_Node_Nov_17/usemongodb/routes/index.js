var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/products', function(req, res, next) {

      // Define where the mongodb db is ?

      var url = "mongodb://localhost:27017/products";
      var MongoClient = mongodb.MongoClient;

      MongoClient.connect(url,function(err,db){
          if(err){
            console.log(err);
          }else{
            console.log('Connected Successfully !');

            var collection = db.collection('products');
            // Find all records

            collection.find({}).toArray(function(err,result){
              if(err){
                console.log(err);                
              }
              else if(result.length){
                res.render('productlist',{
                  productlist:result
                });                
              }
              else{
                res.send('No products found !')
              }
              db.close();
            })
          }
      });
});




module.exports = router;
