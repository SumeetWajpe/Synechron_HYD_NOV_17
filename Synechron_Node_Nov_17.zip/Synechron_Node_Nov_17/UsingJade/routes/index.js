var express = require('express');
var router = express.Router();

router.get('/',function(req,res){
        // res.send('Routing works..')
        res.render('index',{
            msg:'Jade in Express !',
            data:'Using blocks with extending views !',
            users:[
                {name:'Sumeet',age:32},{name:'Tejas',age:22},
                {name:'Amit',age:42}]
        });
});

module.exports = router;