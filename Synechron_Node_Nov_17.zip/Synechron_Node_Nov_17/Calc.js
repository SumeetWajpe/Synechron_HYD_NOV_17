var MathModule = require('./MathModule');

console.log(MathModule.Addition(20,30));