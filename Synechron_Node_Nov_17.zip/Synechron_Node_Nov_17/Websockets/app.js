var socket = require('socket.io');
var http = require('http');
var fs = require('fs');

var server = http.createServer(function(req,res){
        fs.readFile(__dirname+ '/Client.html',function(err,data){        
                res.writeHead(200,{'Content-Type':'text/html'});
                return res.end(data);  
        });// eof readfile
});// eof createServer

var io = socket.listen(server);

io.sockets.on('connection',function(skt){
        setInterval(function(){
                var dataToBeSent = new Date();
                skt.emit('messageForClient',dataToBeSent);
        },2000);

        skt.on('mesageFromClient',function(dataFromClient){
            console.log('Data From Client : ' + dataFromClient)
        })
})

server.listen(5000,'127.0.0.1',function(){
    console.log('Server running at 5000  !');
})