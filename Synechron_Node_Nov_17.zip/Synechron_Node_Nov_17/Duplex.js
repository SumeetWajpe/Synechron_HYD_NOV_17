var nettcp = require('net');
var fs = require('fs');
var writeStream = fs.createWriteStream('InputFromTCP.txt');
var server = nettcp.createServer(function(connect){
        console.log('Connection established...');
        connect.on('end',function(){
            console.log('Connection terminated...')
        });
        connect.write('Some Messages here.. (Default)')
        // connect.on('data',function(){
           
        // })

        connect.pipe(connect).pipe(writeStream);
});

server.listen(6565,function(){
    console.log('Server listening at 6565 !')
});