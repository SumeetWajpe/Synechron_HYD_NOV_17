var http = require('http');
var fs = require('fs');

var portNo = 5555;
var server = http.createServer(function(req,res){
        res.statusCode = 200;
        res.setHeader('Content-Type','text/html');

        fs.readFile('Index.html',function(err,data){
                if(err){
                    console.log(err);
                }else{
                    return res.end(data);
                }
        }) ;
       // res.end('<h1>Hello from Node Server !</h1>');
});

server.listen(portNo,'127.0.0.1',function(){
        console.log('Server running at ' + portNo + " !");
});
