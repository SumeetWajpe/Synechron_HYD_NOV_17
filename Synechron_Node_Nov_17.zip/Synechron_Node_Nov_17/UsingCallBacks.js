
function evenDoubler(theNum,callBack){
        if(theNum %2 == 0){
            setTimeout(function(){
                callBack(null,theNum * 2);
            },2000);
        }else{
            setTimeout(function(){
                callBack(new Error('Odd Input !'),null)
            },3000);
        }
}

function ProcessResult(err,results){
    if(err){
        console.log('Error : ' + err.message);
    }else{
        console.log('Result : ' + results);
    }
}
evenDoubler(2,ProcessResult);
evenDoubler(6,ProcessResult);
evenDoubler(3,ProcessResult);
evenDoubler(8,ProcessResult);
console.log('Program Ended !');
