var express = require('express');

var app = express();

app.get('/',function(req,res){
    var products =[ {Name:'Laptop',Price:40000}, {Name:'Mobile',Price:20000}];
        // res.send('<h1> Welcome to Express ! </h1>')
        // res.sendFile('Index.html',{root:__dirname});
    res.json(products);
});


app.listen(4000,function(){
    console.log('The Server running at 4000 !' )
});