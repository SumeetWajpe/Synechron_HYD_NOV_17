var fs = require('fs');

var readableStream = fs.createReadStream('Input1.txt');// return an emmiter !
var writableStream = fs.createWriteStream('Output.txt');
readableStream.setEncoding('UTF8');

// var allData = '';

// readableStream.on('data',function(chunk){
//     allData += chunk;
// });

// readableStream.on('end',function(){
//     writableStream.write(allData);
//     writableStream.end();
// });


readableStream.on('error',function(err){
    console.log(err.message)
});

console.log('Hello !')
readableStream.pipe(writableStream);